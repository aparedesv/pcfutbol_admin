<template>
    
    <div class="app_container">

        <router-view></router-view>

    </div>

</template>