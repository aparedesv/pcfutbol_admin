import Constants from "./constants.js";

var state = {

    constants: Constants,
    equip: null
};

export default state;